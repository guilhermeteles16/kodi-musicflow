# -*- coding: utf-8 -*-
"""Local persistence (JSON files in the add-on profile folder).

Stored: favourites, local playlists, playback history, recent searches and
short-lived "play contexts" (track lists behind a clicked list item).
No credentials, cookies or tokens are ever stored.
"""
import json
import os
import time
import uuid

from . import log, settings
from .utils import clean_item, clean_text

MAX_CONTEXTS = 15
MAX_CONTEXT_TRACKS = 500
MAX_SEARCHES = 15


def _path(name):
    return os.path.join(settings.profile_dir(), name + ".json")


def load(name, default):
    path = _path(name)
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if type(data) is not type(default):
            raise ValueError("unexpected type in %s" % name)
        return data
    except (OSError, ValueError) as exc:
        log.error("Corrupted data file %s (%s); keeping a backup and starting empty" % (name, exc))
        try:
            os.replace(path, path + ".bad")
        except OSError:
            pass
        return default


def save(name, data):
    path = _path(name)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False)
        os.replace(tmp, path)
        return True
    except OSError as exc:
        log.error("Could not write %s: %s" % (name, exc))
        return False


# ----------------------------------------------------------------- favourites
_FAV_KINDS = ("track", "album", "artist", "playlist")


def _load_favs():
    data = load("favorites", {})
    out = {}
    for kind in _FAV_KINDS:
        rows = data.get(kind, [])
        cleaned = [clean_item(i) for i in rows] if isinstance(rows, list) else []
        out[kind] = [i for i in cleaned if i and i["kind"] == kind]
    return out


def get_favorites(kind):
    return _load_favs().get(kind, [])


def favorite_ids(kind):
    return set(i.get("id") for i in get_favorites(kind))


def is_favorite(kind, item_id):
    return item_id in favorite_ids(kind)


def toggle_favorite(item):
    """Add the item if absent, remove it if present. Returns True when added."""
    item = clean_item(item)
    if item is None:
        return None
    favs = _load_favs()
    bucket = favs[item["kind"]]
    existing = [i for i in bucket if i.get("id") == item["id"]]
    if existing:
        favs[item["kind"]] = [i for i in bucket if i.get("id") != item["id"]]
        added = False
    else:
        bucket.insert(0, item)
        added = True
    save("favorites", favs)
    return added


# ------------------------------------------------------------- local playlists
def _load_playlists():
    data = load("playlists", {"playlists": []})
    lists = data.get("playlists")
    if not isinstance(lists, list):
        return []
    out = []
    for pl in lists:
        if not isinstance(pl, dict) or not pl.get("id"):
            continue
        tracks = pl.get("tracks") if isinstance(pl.get("tracks"), list) else []
        cleaned = [clean_item(t) for t in tracks]
        out.append({"id": str(pl["id"]), "name": clean_text(pl.get("name"), 80) or "?",
                    "created": pl.get("created", 0), "tracks": [t for t in cleaned if t and t["kind"] == "track"]})
    return out


def get_playlists():
    return _load_playlists()


def get_playlist(playlist_id):
    for pl in _load_playlists():
        if pl.get("id") == playlist_id:
            return pl
    return None


def create_playlist(name):
    name = clean_text(name, 80)
    if not name:
        return None
    pl = {"id": uuid.uuid4().hex[:12], "name": name, "created": int(time.time()), "tracks": []}
    lists = _load_playlists()
    lists.append(pl)
    save("playlists", {"playlists": lists})
    return pl


def rename_playlist(playlist_id, name):
    name = clean_text(name, 80)
    if not name:
        return False
    lists = _load_playlists()
    for pl in lists:
        if pl.get("id") == playlist_id:
            pl["name"] = name
            return save("playlists", {"playlists": lists})
    return False


def delete_playlist(playlist_id):
    lists = _load_playlists()
    new = [p for p in lists if p.get("id") != playlist_id]
    if len(new) == len(lists):
        return False
    return save("playlists", {"playlists": new})


def add_track_to_playlist(playlist_id, track):
    track = clean_item(track)
    if track is None or track["kind"] != "track":
        return False
    lists = _load_playlists()
    for pl in lists:
        if pl.get("id") == playlist_id:
            pl.setdefault("tracks", []).append(track)
            return save("playlists", {"playlists": lists})
    return False


def remove_track_from_playlist(playlist_id, index):
    lists = _load_playlists()
    for pl in lists:
        if pl.get("id") == playlist_id:
            tracks = pl.get("tracks", [])
            if 0 <= index < len(tracks):
                del tracks[index]
                return save("playlists", {"playlists": lists})
    return False


# --------------------------------------------------------------------- history
def get_history():
    data = load("history", {"items": []})
    items = data.get("items")
    if not isinstance(items, list):
        return []
    cleaned = [clean_item(i) for i in items]
    return [i for i in cleaned if i and i["kind"] == "track"]


def add_history(track):
    if not settings.get_bool("history_enabled", True):
        return
    track = clean_item(track)
    if track is None:
        return
    items = get_history()
    if items and items[0].get("id") == track["id"]:
        items.pop(0)
    items.insert(0, track)
    limit = max(10, settings.get_int("history_max", 200))
    save("history", {"items": items[:limit]})


def clear_history():
    return save("history", {"items": []})


# ------------------------------------------------------------- recent searches
def get_searches():
    data = load("searches", {"items": []})
    items = data.get("items")
    return [i for i in items if isinstance(i, dict)] if isinstance(items, list) else []


def add_search(query, kind):
    if not settings.get_bool("history_enabled", True):
        return
    query = clean_text(query, 100)
    if not query:
        return
    items = [i for i in get_searches() if not (i.get("q") == query and i.get("kind") == kind)]
    items.insert(0, {"q": query, "kind": kind})
    save("searches", {"items": items[:MAX_SEARCHES]})


# -------------------------------------------------------------- play contexts
def save_context(tracks):
    """Remember a list of tracks so a clicked item can queue the whole list."""
    tracks = [t for t in (clean_item(t) for t in tracks) if t and t["kind"] == "track"]
    tracks = tracks[:MAX_CONTEXT_TRACKS]
    data = load("contexts", {})
    ctx_id = uuid.uuid4().hex[:10]
    data[ctx_id] = {"ts": time.time(), "tracks": tracks}
    if len(data) > MAX_CONTEXTS:
        newest = sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:MAX_CONTEXTS]
        data = dict(newest)
    save("contexts", data)
    return ctx_id


def get_context(ctx_id):
    entry = load("contexts", {}).get(ctx_id)
    if not isinstance(entry, dict):
        return []
    return [t for t in (clean_item(t) for t in entry.get("tracks", [])) if t]


def clear_contexts():
    save("contexts", {})
