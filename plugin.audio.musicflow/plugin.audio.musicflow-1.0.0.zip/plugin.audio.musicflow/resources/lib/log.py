# -*- coding: utf-8 -*-
"""Logging helpers that write to the official Kodi log."""
import traceback

import xbmc

_PREFIX = "[MusicFlow] "


def debug(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGDEBUG)


def info(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGINFO)


def warning(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGWARNING)


def error(msg):
    xbmc.log(_PREFIX + str(msg), xbmc.LOGERROR)


def exception(msg):
    xbmc.log("%s%s\n%s" % (_PREFIX, msg, traceback.format_exc()), xbmc.LOGERROR)
