# -*- coding: utf-8 -*-
"""Typed access to add-on settings and profile paths."""
import os

import xbmcaddon
import xbmcvfs


def _addon():
    # A fresh instance guarantees up-to-date setting values.
    return xbmcaddon.Addon()


def get_str(key, default=""):
    try:
        value = _addon().getSetting(key)
    except Exception:
        value = ""
    return value if value else default


def get_int(key, default=0):
    try:
        return int(_addon().getSettingInt(key))
    except Exception:
        try:
            return int(_addon().getSetting(key))
        except Exception:
            return default


def get_bool(key, default=False):
    try:
        return bool(_addon().getSettingBool(key))
    except Exception:
        value = get_str(key, "")
        if value == "":
            return default
        return value.lower() == "true"


def addon_info(key):
    return _addon().getAddonInfo(key)


def profile_dir():
    path = xbmcvfs.translatePath(addon_info("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def media_path(name):
    return os.path.join(xbmcvfs.translatePath(addon_info("path")), "resources", "media", name)
