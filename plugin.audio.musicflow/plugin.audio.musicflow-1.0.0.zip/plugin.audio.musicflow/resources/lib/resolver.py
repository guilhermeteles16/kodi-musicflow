# -*- coding: utf-8 -*-
"""Turn a YouTube video id into something the Kodi player can open.

The catalogue backends never return audio URLs, so playback is resolved
separately and lazily (when a track actually starts). That also means links
never expire while sitting in a queue.

Methods:
* ``youtube``  - hand the id to Kodi's official YouTube add-on
  (``plugin.video.youtube``), which does the stream resolution.
* ``ytdlp``    - optional: use the ``script.module.yt-dlp`` module to obtain a
  direct audio URL. It is only used if the user selects/has it installed.

No DRM, paywall or authentication restrictions are bypassed: videos that the
service refuses to serve simply fail with a clear message.
"""
import urllib.parse

import xbmc

from . import log, settings
from . import strings as S
from .utils import valid_video_id

YOUTUBE_ADDON = "plugin.video.youtube"
YTDLP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"


def youtube_addon_enabled():
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % YOUTUBE_ADDON))


def ytdlp_available():
    try:
        import yt_dlp  # type: ignore  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _via_youtube_addon(video_id, audio_only):
    if not youtube_addon_enabled():
        return None, S.tr(S.RESOLVER_NO_ADDON)
    url = "plugin://%s/play/?video_id=%s" % (YOUTUBE_ADDON, video_id)
    if audio_only:
        url += "&audio_only=true"
    return url, None


def _via_ytdlp(video_id):
    try:
        import yt_dlp  # type: ignore
    except Exception:  # noqa: BLE001
        return None, S.tr(S.RESOLVER_NO_YTDLP)
    opts = {"format": "bestaudio/best", "quiet": True, "no_warnings": True, "noplaylist": True,
            "socket_timeout": max(5, settings.get_int("network_timeout", 15)), "skip_download": True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info("https://music.youtube.com/watch?v=%s" % video_id, download=False)
        url = (info or {}).get("url")
        if not url:
            return None, S.tr(S.RESOLVER_FAIL, "no stream")
        headers = (info or {}).get("http_headers") or {}
        ua = headers.get("User-Agent") or YTDLP_UA
        return "%s|%s" % (url, urllib.parse.urlencode({"User-Agent": ua})), None
    except Exception as exc:  # noqa: BLE001 - yt-dlp raises many error types
        log.error("yt-dlp failed for %s: %s" % (video_id, exc))
        return None, S.tr(S.RESOLVER_FAIL, str(exc)[:160])


def resolve(video_id):
    """Return ``(url, error_message)``; exactly one of them is None."""
    if not valid_video_id(video_id):
        return None, S.tr(S.INVALID_ID)
    method = settings.get_str("resolver", "auto")
    audio_only = settings.get_bool("audio_only", True)
    if method == "ytdlp":
        return _via_ytdlp(video_id)
    if method == "youtube":
        return _via_youtube_addon(video_id, audio_only)
    # auto: official add-on first, yt-dlp only as a fallback
    url, err = _via_youtube_addon(video_id, audio_only)
    if url:
        return url, None
    if ytdlp_available():
        return _via_ytdlp(video_id)
    return None, err
