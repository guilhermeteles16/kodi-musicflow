# -*- coding: utf-8 -*-
"""URL building, validation and item (de)serialisation helpers."""
import re
from urllib.parse import parse_qsl, urlencode

ADDON_ID = "plugin.audio.musicflow"
BASE_URL = "plugin://%s/" % ADDON_ID

_VIDEO_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
_BROWSE_RE = re.compile(r"^[A-Za-z0-9_-]{4,80}$")
_PLAYLIST_RE = re.compile(r"^[A-Za-z0-9_-]{5,80}$")

KINDS = ("track", "album", "artist", "playlist")

# Short query-string keys used when an item is serialised into a plugin URL.
_KEY_MAP = (
    ("kind", "k"), ("id", "id"), ("title", "t"), ("artist", "a"),
    ("artist_id", "aid"), ("album", "al"), ("album_id", "alid"),
    ("thumb", "th"), ("duration", "d"), ("year", "y"), ("subtitle", "st"),
)


def valid_video_id(value):
    return bool(value) and bool(_VIDEO_RE.match(str(value)))


def valid_browse_id(value):
    return bool(value) and bool(_BROWSE_RE.match(str(value)))


def valid_playlist_id(value):
    return bool(value) and bool(_PLAYLIST_RE.match(str(value)))


def valid_id_for_kind(kind, value):
    if kind == "track":
        return valid_video_id(value)
    if kind == "playlist":
        return valid_playlist_id(value)
    if kind in ("album", "artist"):
        return valid_browse_id(value)
    return False


def clean_text(value, limit=200):
    if value is None:
        return ""
    text = " ".join(str(value).split())
    return text[:limit]


def clean_url(value):
    value = (value or "").strip()
    if value.startswith("https://") or value.startswith("http://"):
        return value[:600]
    return ""


def clean_item(raw):
    """Validate and normalise an item dict. Returns None if unusable."""
    if not isinstance(raw, dict):
        return None
    kind = raw.get("kind")
    item_id = raw.get("id")
    if kind not in KINDS or not valid_id_for_kind(kind, item_id):
        return None
    title = clean_text(raw.get("title"))
    if not title:
        return None
    try:
        duration = int(raw.get("duration") or 0)
    except (TypeError, ValueError):
        duration = 0
    return {
        "kind": kind,
        "id": str(item_id),
        "title": title,
        "artist": clean_text(raw.get("artist")),
        "artist_id": clean_text(raw.get("artist_id"), 80) if valid_browse_id(raw.get("artist_id")) else "",
        "album": clean_text(raw.get("album")),
        "album_id": clean_text(raw.get("album_id"), 80) if valid_browse_id(raw.get("album_id")) else "",
        "thumb": clean_url(raw.get("thumb")),
        "duration": max(0, min(duration, 86400)),
        "year": clean_text(raw.get("year"), 8),
        "subtitle": clean_text(raw.get("subtitle")),
    }


def build_url(**params):
    clean = dict((k, v) for k, v in params.items() if v not in (None, ""))
    return BASE_URL + "?" + urlencode(clean)


def parse_query(query):
    if not query:
        return {}
    return dict(parse_qsl(query.lstrip("?"), keep_blank_values=False))


def item_to_params(item):
    out = {}
    for long_key, short_key in _KEY_MAP:
        value = item.get(long_key)
        if value not in (None, "", 0):
            out[short_key] = value
    return out


def params_to_item(params):
    raw = {}
    for long_key, short_key in _KEY_MAP:
        if short_key in params:
            raw[long_key] = params[short_key]
    return clean_item(raw)


def format_duration(seconds):
    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return ""
    if seconds <= 0:
        return ""
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


_PLAYLIST_LINK_RE = re.compile(r"[?&]list=([A-Za-z0-9_-]+)")


def extract_playlist_id(text):
    """Accept a YouTube / YouTube Music URL or a raw playlist id."""
    text = (text or "").strip()
    if not text:
        return None
    match = _PLAYLIST_LINK_RE.search(text)
    candidate = match.group(1) if match else text
    if candidate.startswith("VL") and len(candidate) > 7:
        candidate = candidate[2:]
    return candidate if valid_playlist_id(candidate) else None
