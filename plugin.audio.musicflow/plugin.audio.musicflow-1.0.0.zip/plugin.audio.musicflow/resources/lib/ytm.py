# -*- coding: utf-8 -*-
"""YouTube Music catalogue access (public data only, no login).

Two interchangeable backends expose the same methods:

* ``InnerTubeClient`` - built-in client using the same public web endpoint
  that music.youtube.com and ``ytmusicapi`` use. Needs no dependency.
* ``YTMusicApiClient`` - thin adapter over the ``ytmusicapi`` library, used
  automatically when that library is importable in Kodi's Python.

Neither backend returns playable audio URLs; see ``resolver.py`` for that.

All methods return plain dicts that ``utils.clean_item`` accepts:
``{"kind": "track"|"album"|"artist"|"playlist", "id", "title", "artist",
"artist_id", "album", "album_id", "thumb", "duration", "year", "subtitle"}``.
"""
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

from . import log, settings
from . import strings as S
from .utils import clean_item

API_ROOT = "https://music.youtube.com/youtubei/v1/"
CLIENT_NAME = "WEB_REMIX"
CLIENT_VERSION = "1.20250101.01.00"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
MAX_RESPONSE_BYTES = 12 * 1024 * 1024
MAX_CONTINUATIONS = 4

# Server-side search filters (same values the web app / ytmusicapi send).
SEARCH_PARAMS = {
    "track": "EgWKAQIIAWoMEA4QChADEAQQCRAF",
    "album": "EgWKAQIYAWoMEA4QChADEAQQCRAF",
    "artist": "EgWKAQIgAWoMEA4QChADEAQQCRAF",
    "playlist": "Eg-KAQwIABAAGAAgACgBMABqChAEEAMQCRAFEAo%3D",
}

SHELF_KEYS = (
    "musicShelfRenderer",
    "musicCarouselShelfRenderer",
    "musicPlaylistShelfRenderer",
    "musicImmersiveCarouselShelfRenderer",
)
HEADER_KEYS = (
    "musicResponsiveHeaderRenderer",
    "musicDetailHeaderRenderer",
    "musicImmersiveHeaderRenderer",
    "musicVisualHeaderRenderer",
)


class YTMError(Exception):
    """Raised for any catalogue failure; the message is user presentable."""


# --------------------------------------------------------------------- HTTP
def _request(endpoint, payload, hl, gl, timeout, query=""):
    url = "%s%s?prettyPrint=false%s" % (API_ROOT, endpoint, ("&" + query) if query else "")
    body = {"context": {"client": {"clientName": CLIENT_NAME, "clientVersion": CLIENT_VERSION,
                                   "hl": hl, "gl": gl}, "user": {}}}
    body.update(payload)
    data = json.dumps(body).encode("utf-8")
    headers = {
        "User-Agent": USER_AGENT,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Accept-Language": hl,
        "Origin": "https://music.youtube.com",
        "Referer": "https://music.youtube.com/",
        "Cookie": "SOCS=CAI",
    }
    last_error = "unknown error"
    for attempt in range(2):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read(MAX_RESPONSE_BYTES + 1)
            if len(raw) > MAX_RESPONSE_BYTES:
                raise YTMError("response too large")
            return json.loads(raw.decode("utf-8"))
        except YTMError:
            raise
        except urllib.error.HTTPError as exc:
            last_error = "HTTP %s" % exc.code
            if exc.code < 500 and exc.code != 429:
                break
        except (urllib.error.URLError, socket.timeout, ConnectionError, OSError, ValueError) as exc:
            last_error = str(getattr(exc, "reason", exc)) or exc.__class__.__name__
        log.warning("Request to %s failed (attempt %d): %s" % (endpoint, attempt + 1, last_error))
        time.sleep(0.4)
    raise YTMError(last_error)


# ------------------------------------------------------------ JSON helpers
def _dig(obj, *path):
    for key in path:
        if isinstance(obj, dict):
            obj = obj.get(key)
        elif isinstance(obj, list) and isinstance(key, int) and -len(obj) <= key < len(obj):
            obj = obj[key]
        else:
            return None
        if obj is None:
            return None
    return obj


def _walk(node):
    """Yield every dict in the JSON tree, in document (pre-)order."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            yield cur
            stack.extend(reversed(list(cur.values())))
        elif isinstance(cur, list):
            stack.extend(reversed(cur))


def _find(node, key):
    for d in _walk(node):
        if key in d:
            yield d[key]


def _runs(node):
    runs = node.get("runs") if isinstance(node, dict) else None
    return runs if isinstance(runs, list) else []


def _text(node):
    return "".join(r.get("text", "") for r in _runs(node) if isinstance(r, dict))


_SIZE_RE = re.compile(r"=w\d+-h\d+")


def _thumb(thumb_container):
    """thumb_container is the dict that holds a ``thumbnails`` list."""
    thumbs = _dig(thumb_container, "thumbnails")
    if not isinstance(thumbs, list) or not thumbs:
        return ""
    best = thumbs[-1]
    url = best.get("url", "") if isinstance(best, dict) else ""
    if url.startswith("//"):
        url = "https:" + url
    if "googleusercontent.com" in url or "ggpht.com" in url:
        url = _SIZE_RE.sub("=w544-h544", url)
    return url if url.startswith("http") else ""


_DUR_RE = re.compile(r"^(?:(\d+):)?(\d{1,2}):(\d{2})$")
_SEP_RE = re.compile(r"^[\s•·,&|\-\u2013\u2014]*$")
_YEAR_RE = re.compile(r"^\d{4}$")


def _parse_duration(text):
    match = _DUR_RE.match((text or "").strip())
    if not match:
        return 0
    h, m, s = match.groups()
    return int(h or 0) * 3600 + int(m) * 60 + int(s)


def _browse_of(node):
    """Return (browseId, pageType) from a navigationEndpoint-like dict."""
    be = _dig(node, "browseEndpoint")
    if not isinstance(be, dict):
        return None, ""
    page_type = _dig(be, "browseEndpointContextSupportedConfigs",
                     "browseEndpointContextMusicConfig", "pageType") or ""
    return be.get("browseId"), page_type


def _kind_for_browse(browse_id, page_type):
    bid = browse_id or ""
    if bid.startswith("MPRE") or "ALBUM" in page_type:
        return "album"
    if bid.startswith(("UC", "MPLA")) or "ARTIST" in page_type or "USER_CHANNEL" in page_type:
        return "artist"
    if bid.startswith(("VL", "PL", "RDCLAK", "OLAK")) or "PLAYLIST" in page_type:
        return "playlist"
    return None


def _linked_artists(runs):
    out = []
    for run in runs:
        bid, _ = _browse_of(run.get("navigationEndpoint"))
        if bid and bid.startswith(("UC", "MPLA")) and run.get("text"):
            out.append((run["text"], bid))
    return out


def _linked_album(runs):
    for run in runs:
        bid, _ = _browse_of(run.get("navigationEndpoint"))
        if bid and bid.startswith("MPRE") and run.get("text"):
            return run["text"], bid
    return "", ""


def _texts(runs):
    return [r.get("text", "") for r in runs if r.get("text", "") and not _SEP_RE.match(r.get("text", ""))]


def _make(kind, item_id, title, d, **extra):
    item = {"kind": kind, "id": item_id, "title": title, "artist": "", "artist_id": "",
            "album": "", "album_id": "", "thumb": "", "duration": 0, "year": "", "subtitle": ""}
    item.update(extra)
    return item


def _finish_media(kind, node_id, title, runs, thumb, d, nav_browse=None):
    """Build an album/artist/playlist item from subtitle runs."""
    texts = _texts(runs)
    artists = _linked_artists(runs)
    year = next((t for t in texts if _YEAR_RE.match(t)), "")
    if kind == "album":
        return _make("album", node_id, title, d, artist=", ".join(a[0] for a in artists) or d.get("artist", ""),
                     artist_id=artists[0][1] if artists else d.get("artist_id", ""), thumb=thumb, year=year)
    if kind == "artist":
        sub = " \u2022 ".join(texts[1:] if len(texts) > 1 else texts)
        return _make("artist", node_id, title, d, thumb=thumb, subtitle=sub)
    if kind == "playlist":
        pid = node_id[2:] if node_id.startswith("VL") else node_id
        author = ", ".join(a[0] for a in artists) or (texts[1] if len(texts) > 2 else "")
        sub = " \u2022 ".join(texts[1:] if len(texts) > 1 else texts)
        return _make("playlist", pid, title, d, artist=author, thumb=thumb, subtitle=sub)
    return None


def _parse_responsive(r, d):
    cols = [_dig(c, "musicResponsiveListItemFlexColumnRenderer", "text") or {} for c in (r.get("flexColumns") or [])]
    title = _text(cols[0]) if cols else ""
    if not title:
        return None
    video_id = (_dig(r, "playlistItemData", "videoId")
                or _dig(r, "overlay", "musicItemThumbnailOverlayRenderer", "content", "musicPlayButtonRenderer",
                        "playNavigationEndpoint", "watchEndpoint", "videoId"))
    browse_id, page_type = _browse_of(r.get("navigationEndpoint"))
    kind = _kind_for_browse(browse_id, page_type)
    meta_runs = []
    for col in cols[1:]:
        meta_runs.extend(_runs(col))
    thumb = _thumb(_dig(r, "thumbnail", "musicThumbnailRenderer", "thumbnail")) or d.get("thumb", "")
    if kind:
        return _finish_media(kind, browse_id, title, meta_runs, thumb, d)
    if not video_id:
        return None
    fixed_runs = []
    for col in (r.get("fixedColumns") or []):
        fixed_runs.extend(_runs(_dig(col, "musicResponsiveListItemFixedColumnRenderer", "text")))
    artists = _linked_artists(meta_runs)
    album, album_id = _linked_album(meta_runs)
    duration = 0
    for run in meta_runs + fixed_runs:
        duration = _parse_duration(run.get("text"))
        if duration:
            break
    return _make("track", video_id, title, d,
                 artist=", ".join(a[0] for a in artists) or d.get("artist", ""),
                 artist_id=artists[0][1] if artists else d.get("artist_id", ""),
                 album=album or d.get("album", ""), album_id=album_id or d.get("album_id", ""),
                 thumb=thumb, duration=duration)


def _parse_two_row(r, d):
    title = _text(r.get("title"))
    if not title:
        return None
    nav = r.get("navigationEndpoint") or {}
    browse_id, page_type = _browse_of(nav)
    kind = _kind_for_browse(browse_id, page_type)
    thumb = _thumb(_dig(r, "thumbnailRenderer", "musicThumbnailRenderer", "thumbnail")) or d.get("thumb", "")
    sub_runs = _runs(r.get("subtitle"))
    if kind:
        return _finish_media(kind, browse_id, title, sub_runs, thumb, d)
    video_id = _dig(nav, "watchEndpoint", "videoId")
    if video_id:
        artists = _linked_artists(sub_runs)
        return _make("track", video_id, title, d,
                     artist=", ".join(a[0] for a in artists) or d.get("artist", ""),
                     artist_id=artists[0][1] if artists else d.get("artist_id", ""), thumb=thumb)
    return None


def _parse_node(node, d):
    if not isinstance(node, dict):
        return None
    r = node.get("musicResponsiveListItemRenderer")
    if isinstance(r, dict):
        return _parse_responsive(r, d)
    r = node.get("musicTwoRowItemRenderer")
    if isinstance(r, dict):
        return _parse_two_row(r, d)
    return None


def _validated(items):
    out, seen = [], set()
    for item in items:
        if not item:
            continue
        clean = clean_item(item)
        if clean is None:
            continue
        key = (clean["kind"], clean["id"])
        if key in seen:
            continue
        seen.add(key)
        out.append(clean)
    return out


def _parse_contents(contents, d):
    """Parse direct children of a shelf's ``contents`` list."""
    return _validated(_parse_node(n, d) for n in (contents or []))


def _parse_deep(resp, d):
    """Parse every list-item renderer anywhere in the response."""
    items = []
    for key in ("musicResponsiveListItemRenderer", "musicTwoRowItemRenderer"):
        for r in _find(resp, key):
            items.append(_parse_node({key: r}, d))
    return _validated(items)


def _shelf_title(shelf):
    return (_text(shelf.get("title"))
            or _text(_dig(shelf, "header", "musicCarouselShelfBasicHeaderRenderer", "title"))
            or _text(_dig(shelf, "header", "musicImmersiveCarouselShelfBasicHeaderRenderer", "title")))


def parse_sections(resp, d):
    """Return ``[{"title": str, "items": [item, ...]}, ...]`` in page order."""
    sections = []
    for node in _walk(resp):
        for key in SHELF_KEYS:
            shelf = node.get(key)
            if isinstance(shelf, dict):
                items = _parse_contents(shelf.get("contents"), d)
                if items:
                    sections.append({"title": _shelf_title(shelf), "items": items})
    return sections


def _find_token(resp):
    for d in _find(resp, "nextContinuationData"):
        if isinstance(d, dict) and d.get("continuation"):
            return d["continuation"]
    for d in _find(resp, "continuationCommand"):
        if isinstance(d, dict) and d.get("token"):
            return d["token"]
    return None


def _parse_header(resp):
    for key in HEADER_KEYS:
        for h in _find(resp, key):
            if not isinstance(h, dict):
                continue
            title = _text(h.get("title"))
            if not title:
                continue
            artists = _linked_artists(_runs(h.get("straplineTextOne"))) or _linked_artists(_runs(h.get("subtitle")))
            return {
                "title": title,
                "artist": ", ".join(a[0] for a in artists),
                "artist_id": artists[0][1] if artists else "",
                "thumb": _thumb(_dig(h, "thumbnail", "musicThumbnailRenderer", "thumbnail")),
            }
    return {"title": "", "artist": "", "artist_id": "", "thumb": ""}


# ------------------------------------------------- built-in (innertube) client
class InnerTubeClient(object):
    name = "innertube"

    def __init__(self):
        self.hl = settings.get_str("catalog_language", "pt-BR")
        self.gl = settings.get_str("catalog_region", "BR")
        self.timeout = max(5, settings.get_int("network_timeout", 15))

    def _post(self, endpoint, payload, query=""):
        return _request(endpoint, payload, self.hl, self.gl, self.timeout, query)

    def _continue(self, endpoint, token):
        q = urllib.parse.quote(token, safe="")
        return self._post(endpoint, {}, "ctoken=%s&continuation=%s&type=next" % (q, q))

    def search(self, query, kind, limit):
        params = SEARCH_PARAMS.get(kind)
        payload = {"query": query}
        if params:
            payload["params"] = params
        resp = self._post("search", payload)
        items = self._search_items(resp)
        wanted = [i for i in items if i["kind"] == kind]
        if not wanted and params:
            log.info("Filtered search returned nothing; retrying unfiltered for %s" % kind)
            resp = self._post("search", {"query": query})
            wanted = [i for i in self._search_items(resp) if i["kind"] == kind]
        token = _find_token(resp)
        loops = 0
        while token and len(wanted) < limit and loops < MAX_CONTINUATIONS:
            loops += 1
            try:
                more = self._continue("search", token)
            except YTMError as exc:
                log.warning("Search continuation failed: %s" % exc)
                break
            new = [i for i in _parse_deep(more, {}) if i["kind"] == kind]
            known = set(i["id"] for i in wanted)
            wanted.extend(i for i in new if i["id"] not in known)
            token = _find_token(more)
        return wanted[:limit]

    @staticmethod
    def _search_items(resp):
        shelves = [s for s in _find(resp, "musicShelfRenderer") if isinstance(s, dict)]
        if shelves:
            items = []
            for shelf in shelves:
                items.extend(_parse_contents(shelf.get("contents"), {}))
            return _validated(items)
        return _parse_deep(resp, {})

    def _tracks_from_shelves(self, resp, defaults, limit):
        shelves = [s for s in _find(resp, "musicPlaylistShelfRenderer") if isinstance(s, dict)]
        if not shelves:
            shelves = [s for s in _find(resp, "musicShelfRenderer") if isinstance(s, dict)]
        tracks = []
        for shelf in shelves:
            tracks.extend(i for i in _parse_contents(shelf.get("contents"), defaults) if i["kind"] == "track")
        token = _find_token(resp)
        loops = 0
        while token and len(tracks) < limit and loops < 20:
            loops += 1
            try:
                more = self._continue("browse", token)
            except YTMError as exc:
                log.warning("Playlist continuation failed: %s" % exc)
                break
            known = set(t["id"] for t in tracks)
            tracks.extend(i for i in _parse_deep(more, defaults) if i["kind"] == "track" and i["id"] not in known)
            token = _find_token(more)
        return tracks[:limit]

    def get_album(self, browse_id):
        resp = self._post("browse", {"browseId": browse_id})
        head = _parse_header(resp)
        defaults = {"artist": head["artist"], "artist_id": head["artist_id"], "album": head["title"],
                    "album_id": browse_id, "thumb": head["thumb"]}
        return {"title": head["title"], "artist": head["artist"], "thumb": head["thumb"],
                "tracks": self._tracks_from_shelves(resp, defaults, 500)}

    def get_playlist(self, playlist_id):
        resp = self._post("browse", {"browseId": "VL" + playlist_id})
        head = _parse_header(resp)
        return {"title": head["title"], "artist": head["artist"], "thumb": head["thumb"],
                "tracks": self._tracks_from_shelves(resp, {}, 500)}

    def get_artist(self, browse_id):
        resp = self._post("browse", {"browseId": browse_id})
        head = _parse_header(resp)
        defaults = {"artist": head["title"], "artist_id": browse_id}
        return {"title": head["title"], "thumb": head["thumb"], "sections": parse_sections(resp, defaults)}

    def get_charts(self):
        payload = {"browseId": "FEmusic_charts"}
        if self.gl:
            payload["formData"] = {"selectedValues": [self.gl]}
        return parse_sections(self._post("browse", payload), {})

    def get_home(self):
        return parse_sections(self._post("browse", {"browseId": "FEmusic_home"}), {})

    def ping(self):
        started = time.time()
        self._post("search", {"query": "music"})
        return int((time.time() - started) * 1000)


# ------------------------------------------------------ ytmusicapi adapter
def _ytmapi_artists(lst):
    names = [a.get("name") for a in (lst or []) if isinstance(a, dict) and a.get("name")]
    ids = [a.get("id") for a in (lst or []) if isinstance(a, dict) and a.get("id")]
    return ", ".join(names), (ids[0] if ids else "")


def _ytmapi_thumb(thumbs):
    if isinstance(thumbs, list) and thumbs and isinstance(thumbs[-1], dict):
        return thumbs[-1].get("url", "")
    return ""


def _ytmapi_item(d, defaults=None):
    """Convert one ytmusicapi result dict to our item format (or None)."""
    defaults = defaults or {}
    if not isinstance(d, dict):
        return None
    thumb = _ytmapi_thumb(d.get("thumbnails") or d.get("thumbnail")) or defaults.get("thumb", "")
    artists = d.get("artists")
    if artists is None and d.get("artist") and not d.get("browseId"):
        artists = [{"name": d.get("artist")}]
    artist, artist_id = _ytmapi_artists(artists)
    album = d.get("album") if isinstance(d.get("album"), dict) else {}
    if d.get("videoId"):
        return _make("track", d["videoId"], d.get("title") or "", defaults,
                     artist=artist or defaults.get("artist", ""), artist_id=artist_id or defaults.get("artist_id", ""),
                     album=album.get("name") or defaults.get("album", ""),
                     album_id=album.get("id") or defaults.get("album_id", ""),
                     thumb=thumb, duration=int(d.get("duration_seconds") or 0))
    bid = d.get("browseId") or ""
    kind = _kind_for_browse(bid, "") or ("playlist" if d.get("playlistId") else None)
    if kind == "album":
        return _make("album", bid, d.get("title") or "", defaults, artist=artist or defaults.get("artist", ""),
                     artist_id=artist_id or defaults.get("artist_id", ""), thumb=thumb, year=str(d.get("year") or ""))
    if kind == "artist":
        return _make("artist", bid, d.get("artist") or d.get("title") or "", defaults, thumb=thumb,
                     subtitle=d.get("subscribers") or "")
    if kind == "playlist":
        pid = bid[2:] if bid.startswith("VL") else (bid or d.get("playlistId") or "")
        author = d.get("author")
        if isinstance(author, list):
            author = _ytmapi_artists(author)[0]
        elif isinstance(author, dict):
            author = author.get("name", "")
        return _make("playlist", pid, d.get("title") or "", defaults, artist=author or "", thumb=thumb,
                     subtitle=str(d.get("itemCount") or ""))
    return None


class YTMusicApiClient(object):
    name = "ytmusicapi"

    def __init__(self, ytmusic_class):
        language = (settings.get_str("catalog_language", "pt-BR") or "en").split("-")[0]
        self.gl = settings.get_str("catalog_region", "BR")
        try:
            self.api = ytmusic_class(language=language, location=self.gl)
        except Exception:
            self.api = ytmusic_class()

    def search(self, query, kind, limit):
        filters = {"track": "songs", "album": "albums", "artist": "artists", "playlist": "playlists"}
        raw = self.api.search(query, filter=filters[kind], limit=limit)
        return _validated(_ytmapi_item(d) for d in raw)[:limit]

    def get_album(self, browse_id):
        data = self.api.get_album(browse_id)
        artist, artist_id = _ytmapi_artists(data.get("artists"))
        thumb = _ytmapi_thumb(data.get("thumbnails"))
        defaults = {"artist": artist, "artist_id": artist_id, "album": data.get("title", ""),
                    "album_id": browse_id, "thumb": thumb}
        tracks = [i for i in _validated(_ytmapi_item(t, defaults) for t in data.get("tracks", [])) if i["kind"] == "track"]
        return {"title": data.get("title", ""), "artist": artist, "thumb": thumb, "tracks": tracks}

    def get_playlist(self, playlist_id):
        data = self.api.get_playlist(playlist_id, limit=500)
        tracks = [i for i in _validated(_ytmapi_item(t) for t in data.get("tracks", [])) if i["kind"] == "track"]
        return {"title": data.get("title", ""), "artist": "", "thumb": _ytmapi_thumb(data.get("thumbnails")),
                "tracks": tracks}

    def get_artist(self, browse_id):
        data = self.api.get_artist(browse_id)
        name = data.get("name", "")
        defaults = {"artist": name, "artist_id": browse_id}
        plan = (("songs", S.SONGS), ("albums", S.ALBUMS), ("singles", S.SINGLES),
                ("videos", S.VIDEOS), ("related", S.RELATED))
        sections = []
        for key, title_id in plan:
            block = data.get(key)
            results = block.get("results") if isinstance(block, dict) else None
            items = _validated(_ytmapi_item(r, defaults) for r in (results or []))
            if items:
                sections.append({"title": S.tr(title_id), "items": items})
        return {"title": name, "thumb": _ytmapi_thumb(data.get("thumbnails")), "sections": sections}

    def get_charts(self):
        data = self.api.get_charts(self.gl)
        sections = []
        for key, block in data.items():
            rows = block.get("items") if isinstance(block, dict) else block
            if isinstance(rows, list):
                items = _validated(_ytmapi_item(r) for r in rows)
                if items:
                    sections.append({"title": str(key).capitalize(), "items": items})
        return sections

    def get_home(self):
        sections = []
        for shelf in self.api.get_home(limit=6):
            items = _validated(_ytmapi_item(r) for r in shelf.get("contents", []))
            if items:
                sections.append({"title": shelf.get("title", ""), "items": items})
        return sections

    def ping(self):
        started = time.time()
        self.api.search("music", filter="songs", limit=1)
        return int((time.time() - started) * 1000)


class _Chain(object):
    """Try the primary backend, transparently fall back to the secondary."""

    def __init__(self, primary, secondary):
        self.primary, self.secondary = primary, secondary
        self.name = primary.name

    def __getattr__(self, attr):
        def call(*args, **kwargs):
            try:
                return getattr(self.primary, attr)(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001 - any library failure triggers fallback
                log.warning("%s.%s failed (%s); falling back to built-in client" % (self.primary.name, attr, exc))
                return getattr(self.secondary, attr)(*args, **kwargs)
        return call


def backend_info():
    """Return (active_backend_name, ytmusicapi_version_or_None)."""
    try:
        import ytmusicapi  # type: ignore
        return "ytmusicapi", getattr(ytmusicapi, "__version__", "?")
    except Exception:  # noqa: BLE001
        return "innertube", None


def get_client():
    builtin = InnerTubeClient()
    if settings.get_str("backend", "auto") == "builtin":
        return builtin
    try:
        from ytmusicapi import YTMusic  # type: ignore
        return _Chain(YTMusicApiClient(YTMusic), builtin)
    except Exception:  # noqa: BLE001 - library absent or failed to initialise
        return builtin
