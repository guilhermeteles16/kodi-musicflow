# -*- coding: utf-8 -*-
"""Plugin router and native Kodi list/dialog UI.

The interface is built from Kodi's own directory listings (lists, art,
context menus, dialogs), so it works with any skin, remote control, keyboard
or mouse. Playback uses Kodi's native music player and playlist.
"""
import json
import platform
import random
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from . import cache, log, resolver, settings, storage, ytm
from . import strings as S
from .strings import tr
from .utils import (KINDS, build_url, extract_playlist_id, format_duration, item_to_params, params_to_item,
                    parse_query, valid_browse_id, valid_playlist_id)

# Actions that run through RunPlugin()/execute builtins (no directory listing).
_NO_LISTING = frozenset([
    "play_list", "play", "fav_toggle", "pl_add", "pl_new", "pl_rename", "pl_delete", "pl_remove_track",
    "pl_open_id", "queue_add", "queue_jump", "queue_remove", "queue_clear", "history_clear",
    "clear_cache", "diagnostics", "open_settings",
])


class Plugin(object):
    def __init__(self, handle, params):
        self.handle = handle
        self.params = params
        self._client = None

    # ------------------------------------------------------------ plumbing
    @property
    def client(self):
        if self._client is None:
            self._client = ytm.get_client()
        return self._client

    def _lang_key(self):
        return "%s:%s" % (settings.get_str("catalog_language", "pt-BR"), settings.get_str("catalog_region", "BR"))

    def _cached(self, key, loader):
        full_key = "%s:%s" % (key, self._lang_key())
        data = cache.get(full_key)
        if data is None:
            data = loader()
            cache.set(full_key, data)
        return data

    def _notify(self, message, icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
        xbmcgui.Dialog().notification(tr(S.ADDON_NAME), message, icon, ms)

    def _fail(self, message):
        """Show an error to the user and abort the current listing."""
        xbmcgui.Dialog().ok(tr(S.ADDON_NAME), message)
        self._end(False)

    def _empty(self, message=None):
        self._notify(message or tr(S.NO_RESULTS))
        self._end(False)

    def _end(self, ok=True, content=None, update=False, title=None):
        if title:
            xbmcplugin.setPluginCategory(self.handle, title)
        if content:
            xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, succeeded=ok, updateListing=update, cacheToDisc=False)

    def _refresh(self):
        xbmc.executebuiltin("Container.Refresh")

    # ---------------------------------------------------- list item builders
    def _art(self, thumb, icon="DefaultMusicSongs.png"):
        return {"thumb": thumb or icon, "icon": icon, "poster": thumb or icon,
                "fanart": settings.media_path("fanart.png")}

    @staticmethod
    def _music_tag(li, item, media):
        title, artist, album = item.get("title", ""), item.get("artist", ""), item.get("album", "")
        try:
            tag = li.getMusicInfoTag()
            tag.setTitle(title)
            if artist:
                tag.setArtist(artist)
            if album:
                tag.setAlbum(album)
            if item.get("duration"):
                tag.setDuration(int(item["duration"]))
            tag.setMediaType(media)
        except AttributeError:  # Kodi 19: InfoTagMusic is read-only
            info = {"title": title, "mediatype": media}
            if artist:
                info["artist"] = artist
            if album:
                info["album"] = album
            if item.get("duration"):
                info["duration"] = int(item["duration"])
            li.setInfo("music", info)

    def _dir(self, label, url, icon="DefaultFolder.png", thumb=None, context=None, folder=True):
        li = xbmcgui.ListItem(label=label, offscreen=True)
        li.setArt(self._art(thumb, icon))
        if context:
            li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(self.handle, url, li, isFolder=folder)

    def _action(self, label, url, icon="DefaultAddonService.png"):
        self._dir(label, url, icon=icon, folder=False)

    def _track_item(self, track, playable=False, context=None):
        label = "%s - %s" % (track["artist"], track["title"]) if track.get("artist") else track["title"]
        li = xbmcgui.ListItem(label=label, offscreen=True)
        li.setLabel2(format_duration(track.get("duration")))
        self._music_tag(li, track, "song")
        li.setArt(self._art(track.get("thumb")))
        if playable:
            li.setProperty("IsPlayable", "true")
        if context:
            li.addContextMenuItems(context)
        return li

    def _fav_label(self, kind, item_id, fav_ids=None):
        is_fav = (item_id in fav_ids) if fav_ids is not None else storage.is_favorite(kind, item_id)
        return tr(S.FAV_REMOVE) if is_fav else tr(S.FAV_ADD)

    def _track_context(self, track, fav_ids, local_pl=None, index=None):
        params = item_to_params(track)
        menu = [
            (self._fav_label("track", track["id"], fav_ids), "RunPlugin(%s)" % build_url(action="fav_toggle", **params)),
            (tr(S.PL_ADD_TO), "RunPlugin(%s)" % build_url(action="pl_add", **params)),
            (tr(S.QUEUE_ADD), "RunPlugin(%s)" % build_url(action="queue_add", **params)),
        ]
        if track.get("artist_id"):
            menu.append((tr(S.GO_ARTIST), "Container.Update(%s)" % build_url(action="artist", id=track["artist_id"])))
        if track.get("album_id"):
            menu.append((tr(S.GO_ALBUM), "Container.Update(%s)" % build_url(action="album", id=track["album_id"])))
        if local_pl is not None and index is not None:
            menu.append((tr(S.PL_REMOVE_TRACK),
                         "RunPlugin(%s)" % build_url(action="pl_remove_track", pl=local_pl, index=index)))
        return menu

    def _render_tracks(self, tracks, local_pl=None, play_all=True):
        """Add playable track rows. Clicking one queues the whole list."""
        ctx = storage.save_context(tracks)
        fav_ids = storage.favorite_ids("track")
        if play_all and tracks:
            self._action("[B]> %s[/B]" % tr(S.PLAY_ALL), build_url(action="play_list", ctx=ctx, index=0),
                         "DefaultMusicPlaylists.png")
            self._action(tr(S.SHUFFLE), build_url(action="play_list", ctx=ctx, shuffle=1),
                         "DefaultMusicPlaylists.png")
        for index, track in enumerate(tracks):
            li = self._track_item(track, context=self._track_context(track, fav_ids, local_pl, index))
            xbmcplugin.addDirectoryItem(self.handle, build_url(action="play_list", ctx=ctx, index=index), li,
                                        isFolder=False)

    def _render_media(self, item, fav_ids):
        kind = item["kind"]
        label = item["title"]
        if kind == "album":
            if item.get("artist"):
                label = "%s - %s" % (item["artist"], label)
            if item.get("year"):
                label = "%s (%s)" % (label, item["year"])
            icon = "DefaultMusicAlbums.png"
        elif kind == "artist":
            icon = "DefaultMusicArtists.png"
        else:
            if item.get("artist"):
                label = "%s - %s" % (label, item["artist"])
            icon = "DefaultMusicPlaylists.png"
        li = xbmcgui.ListItem(label=label, offscreen=True)
        li.setLabel2(item.get("subtitle", "") if kind != "album" else "")
        li.setArt(self._art(item.get("thumb"), icon))
        media = {"album": "album", "artist": "artist"}.get(kind, "music")
        if kind == "artist":
            self._music_tag(li, {"title": item["title"], "artist": item["title"]}, media)
        else:
            self._music_tag(li, {"title": item["title"], "artist": item.get("artist", ""),
                                 "album": item["title"] if kind == "album" else ""}, media)
        li.addContextMenuItems([(self._fav_label(kind, item["id"], fav_ids.get(kind)),
                                 "RunPlugin(%s)" % build_url(action="fav_toggle", **item_to_params(item)))])
        xbmcplugin.addDirectoryItem(self.handle, build_url(action=kind, id=item["id"]), li, isFolder=True)

    def _render_items(self, items):
        """Render a mixed list of tracks / albums / artists / playlists."""
        fav_ids = dict((k, storage.favorite_ids(k)) for k in KINDS)
        tracks = [i for i in items if i["kind"] == "track"]
        ctx = storage.save_context(tracks) if tracks else None
        track_ids = fav_ids["track"]
        t_index = 0
        for item in items:
            if item["kind"] == "track":
                li = self._track_item(item, context=self._track_context(item, track_ids))
                xbmcplugin.addDirectoryItem(self.handle, build_url(action="play_list", ctx=ctx, index=t_index),
                                            li, isFolder=False)
                t_index += 1
            else:
                self._render_media(item, fav_ids)
        content = "songs" if tracks and len(tracks) == len(items) else "files"
        return content

    # ------------------------------------------------------------- menus
    def main_menu(self):
        entries = (
            (S.HOME, "home", "DefaultMusicRecentlyAdded.png"),
            (S.SEARCH, "search_menu", "DefaultAddonsSearch.png"),
            (S.POPULAR, "popular_menu", "DefaultMusicTop100.png"),
            (S.ARTISTS, "artists_menu", "DefaultMusicArtists.png"),
            (S.ALBUMS, "albums_menu", "DefaultMusicAlbums.png"),
            (S.PLAYLISTS, "playlists_menu", "DefaultMusicPlaylists.png"),
            (S.FAVORITES, "favorites_menu", "DefaultFavourites.png"),
            (S.HISTORY, "history", "DefaultMusicRecentlyPlayed.png"),
            (S.QUEUE, "queue", "DefaultPlaylist.png"),
        )
        for string_id, action, icon in entries:
            self._dir(tr(string_id), build_url(action=action), icon=icon)
        self._action(tr(S.SETTINGS), build_url(action="open_settings"), "DefaultAddonService.png")
        self._end(title=tr(S.ADDON_NAME))

    def home(self):
        recent = storage.get_history()[:10]
        self._dir(tr(S.SEARCH), build_url(action="search_menu"), "DefaultAddonsSearch.png")
        self._dir(tr(S.POPULAR), build_url(action="popular_menu"), "DefaultMusicTop100.png")
        self._dir(tr(S.FAVORITES), build_url(action="favorites_menu"), "DefaultFavourites.png")
        if recent:
            self._render_tracks(recent)
        elif not settings.get_bool("history_enabled", True):
            self._action(tr(S.HISTORY_DISABLED), build_url(action="open_settings"))
        else:
            self._dir(tr(S.START_HINT), build_url(action="search_menu"), "DefaultAddonsSearch.png")
        self._end(content="songs", title=tr(S.HOME))

    def search_menu(self):
        entries = (("track", S.SEARCH_SONGS), ("artist", S.SEARCH_ARTISTS),
                   ("album", S.SEARCH_ALBUMS), ("playlist", S.SEARCH_PLAYLISTS))
        for kind, string_id in entries:
            self._dir(tr(string_id), build_url(action="search", kind=kind), "DefaultAddonsSearch.png")
        recents = storage.get_searches()
        if recents:
            self._action("[COLOR gray]%s[/COLOR]" % tr(S.RECENT_SEARCHES), build_url(action="search_menu"))
            for entry in recents:
                kind = entry.get("kind")
                if kind in KINDS and entry.get("q"):
                    self._dir(entry["q"], build_url(action="search", kind=kind, q=entry["q"]),
                              "DefaultMusicSearch.png")
        self._end(title=tr(S.SEARCH))

    def search(self):
        kind = self.params.get("kind", "track")
        if kind not in KINDS:
            return self._fail(tr(S.INVALID_ID))
        query = (self.params.get("q") or "").strip()
        if not query:
            query = xbmcgui.Dialog().input(tr(S.SEARCH_PROMPT), type=xbmcgui.INPUT_ALPHANUM).strip()
        query = " ".join(query.split())[:100]
        if not query:
            return self._end(False)
        limit = max(5, settings.get_int("results_limit", 20))
        results = self._cached("search:%s:%d:%s" % (kind, limit, query.lower()),
                               lambda: self.client.search(query, kind, limit))
        storage.add_search(query, kind)
        if not results:
            return self._empty()
        if kind == "track":
            self._render_tracks(results)
            return self._end(content="songs", title=query)
        fav_ids = dict((k, storage.favorite_ids(k)) for k in KINDS)
        for item in results:
            self._render_media(item, fav_ids)
        self._end(content={"album": "albums", "artist": "artists"}.get(kind, "files"), title=query)

    # ------------------------------------------- popular / sections / artist
    def popular_menu(self):
        self._dir(tr(S.CHARTS), build_url(action="sections", src="charts"), "DefaultMusicTop100.png")
        self._dir(tr(S.RECOMMENDED), build_url(action="sections", src="home"), "DefaultMusicRecentlyAdded.png")
        self._end(title=tr(S.POPULAR))

    def _load_sections(self, src, sid):
        if src == "charts":
            return self._cached("charts", lambda: {"title": tr(S.CHARTS), "thumb": "",
                                                   "sections": self.client.get_charts()})
        if src == "home":
            return self._cached("home", lambda: {"title": tr(S.RECOMMENDED), "thumb": "",
                                                 "sections": self.client.get_home()})
        if src == "artist" and valid_browse_id(sid):
            return self._cached("artist:%s" % sid, lambda: self.client.get_artist(sid))
        return None

    def sections(self):
        src, sid = self.params.get("src", ""), self.params.get("id", "")
        data = self._load_sections(src, sid)
        if data is None:
            return self._fail(tr(S.INVALID_ID))
        sections = data.get("sections") or []
        if not sections:
            return self._empty()
        if src == "artist":
            artist = {"kind": "artist", "id": sid, "title": data.get("title") or "?", "thumb": data.get("thumb", "")}
            label = self._fav_label("artist", sid)
            self._action("[B]%s[/B]" % label, build_url(action="fav_toggle", **item_to_params(artist)),
                         "DefaultFavourites.png")
        for index, section in enumerate(sections):
            title = section.get("title") or "#%d" % (index + 1)
            thumb = next((i.get("thumb") for i in section["items"] if i.get("thumb")), None)
            self._dir("%s (%d)" % (title, len(section["items"])),
                      build_url(action="section", src=src, id=sid, index=index), "DefaultMusicSongs.png", thumb)
        self._end(title=data.get("title") or tr(S.ADDON_NAME))

    def section(self):
        src, sid = self.params.get("src", ""), self.params.get("id", "")
        data = self._load_sections(src, sid)
        try:
            section = (data or {}).get("sections", [])[int(self.params.get("index", "0"))]
        except (ValueError, IndexError, TypeError):
            return self._fail(tr(S.INVALID_ID))
        items = section.get("items") or []
        if not items:
            return self._empty()
        content = self._render_items(items)
        self._end(content=content, title=section.get("title"))

    def artist(self):
        self.params["src"] = "artist"
        self.sections()

    def album(self):
        self._tracklist("album", self.params.get("id", ""), valid_browse_id)

    def playlist(self):
        self._tracklist("playlist", self.params.get("id", ""), valid_playlist_id)

    def _tracklist(self, kind, item_id, validator):
        if not validator(item_id):
            return self._fail(tr(S.INVALID_ID))
        loader = self.client.get_album if kind == "album" else self.client.get_playlist
        data = self._cached("%s:%s" % (kind, item_id), lambda: loader(item_id))
        tracks = data.get("tracks") or []
        if not tracks:
            return self._empty()
        fav_item = {"kind": kind, "id": item_id, "title": data.get("title") or "?",
                    "artist": data.get("artist", ""), "thumb": data.get("thumb", "")}
        self._action(self._fav_label(kind, item_id), build_url(action="fav_toggle", **item_to_params(fav_item)),
                     "DefaultFavourites.png")
        self._render_tracks(tracks)
        self._end(content="songs", title=data.get("title"))

    # ----------------------------------------------------------- library menus
    def artists_menu(self):
        self._dir(tr(S.SEARCH_ARTISTS), build_url(action="search", kind="artist"), "DefaultAddonsSearch.png")
        self._dir("%s (%d)" % (tr(S.FAV_ARTISTS), len(storage.get_favorites("artist"))),
                  build_url(action="fav_list", kind="artist"), "DefaultMusicArtists.png")
        self._end(title=tr(S.ARTISTS))

    def albums_menu(self):
        self._dir(tr(S.SEARCH_ALBUMS), build_url(action="search", kind="album"), "DefaultAddonsSearch.png")
        self._dir("%s (%d)" % (tr(S.FAV_ALBUMS), len(storage.get_favorites("album"))),
                  build_url(action="fav_list", kind="album"), "DefaultMusicAlbums.png")
        self._end(title=tr(S.ALBUMS))

    def playlists_menu(self):
        self._action(tr(S.PL_NEW), build_url(action="pl_new"), "DefaultAddSource.png")
        for pl in storage.get_playlists():
            menu = [(tr(S.PL_RENAME), "RunPlugin(%s)" % build_url(action="pl_rename", pl=pl["id"])),
                    (tr(S.PL_DELETE), "RunPlugin(%s)" % build_url(action="pl_delete", pl=pl["id"]))]
            thumb = next((t.get("thumb") for t in pl.get("tracks", []) if t.get("thumb")), None)
            self._dir("%s (%d)" % (pl.get("name", "?"), len(pl.get("tracks", []))),
                      build_url(action="local_playlist", pl=pl["id"]), "DefaultMusicPlaylists.png", thumb, menu)
        self._dir("%s (%d)" % (tr(S.PL_SAVED_YT), len(storage.get_favorites("playlist"))),
                  build_url(action="fav_list", kind="playlist"), "DefaultMusicPlaylists.png")
        self._dir(tr(S.SEARCH_PLAYLISTS), build_url(action="search", kind="playlist"), "DefaultAddonsSearch.png")
        self._action(tr(S.PL_OPEN_ID), build_url(action="pl_open_id"), "DefaultNetwork.png")
        self._end(title=tr(S.PLAYLISTS))

    def local_playlist(self):
        pl = storage.get_playlist(self.params.get("pl", ""))
        if pl is None:
            return self._fail(tr(S.INVALID_ID))
        tracks = pl.get("tracks", [])
        if not tracks:
            return self._empty(tr(S.PL_LOCAL_EMPTY))
        self._render_tracks(tracks, local_pl=pl["id"])
        self._end(content="songs", title=pl.get("name"))

    def favorites_menu(self):
        entries = (("track", S.FAV_SONGS, "DefaultMusicSongs.png"), ("album", S.FAV_ALBUMS, "DefaultMusicAlbums.png"),
                   ("artist", S.FAV_ARTISTS, "DefaultMusicArtists.png"),
                   ("playlist", S.FAV_PLAYLISTS, "DefaultMusicPlaylists.png"))
        for kind, string_id, icon in entries:
            self._dir("%s (%d)" % (tr(string_id), len(storage.get_favorites(kind))),
                      build_url(action="fav_list", kind=kind), icon)
        self._end(title=tr(S.FAVORITES))

    def fav_list(self):
        kind = self.params.get("kind", "")
        if kind not in KINDS:
            return self._fail(tr(S.INVALID_ID))
        items = storage.get_favorites(kind)
        if not items:
            return self._empty(tr(S.EMPTY_LIST))
        if kind == "track":
            self._render_tracks(items)
            return self._end(content="songs", title=tr(S.FAV_SONGS))
        fav_ids = dict((k, storage.favorite_ids(k)) for k in KINDS)
        for item in items:
            self._render_media(item, fav_ids)
        self._end(content={"album": "albums", "artist": "artists"}.get(kind, "files"))

    def history(self):
        if not settings.get_bool("history_enabled", True) and not storage.get_history():
            return self._empty(tr(S.HISTORY_DISABLED))
        items = storage.get_history()
        if not items:
            return self._empty(tr(S.EMPTY_LIST))
        self._action("[COLOR red]%s[/COLOR]" % tr(S.HISTORY_CLEAR), build_url(action="history_clear"),
                     "DefaultAddonNone.png")
        self._render_tracks(items)
        self._end(content="songs", title=tr(S.HISTORY))

    # ------------------------------------------------------------- queue
    def queue(self):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        size = playlist.size()
        if size == 0:
            return self._empty(tr(S.QUEUE_EMPTY))
        current = playlist.getposition() if xbmc.Player().isPlayingAudio() else -1
        self._action("[COLOR red]%s[/COLOR]" % tr(S.QUEUE_CLEAR), build_url(action="queue_clear"),
                     "DefaultAddonNone.png")
        for pos in range(size):
            entry = playlist[pos]
            label = entry.getLabel() or entry.getPath()
            if pos == current:
                label = "[B]> %s[/B]" % label
            li = xbmcgui.ListItem(label=label, offscreen=True)
            try:
                li.setArt({"thumb": entry.getArt("thumb") or "DefaultMusicSongs.png"})
            except Exception:  # noqa: BLE001 - art is cosmetic only
                pass
            li.addContextMenuItems([(tr(S.QUEUE_REMOVE),
                                     "RunPlugin(%s)" % build_url(action="queue_remove", pos=pos))])
            xbmcplugin.addDirectoryItem(self.handle, build_url(action="queue_jump", pos=pos), li, isFolder=False)
        self._end(content="songs", title=tr(S.QUEUE))

    def queue_jump(self):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        pos = self._int("pos", -1)
        if 0 <= pos < playlist.size():
            xbmc.Player().play(playlist, startpos=pos)

    def queue_remove(self):
        pos = self._int("pos", -1)
        if pos >= 0:
            request = {"jsonrpc": "2.0", "id": 1, "method": "Playlist.Remove",
                       "params": {"playlistid": 0, "position": pos}}
            xbmc.executeJSONRPC(json.dumps(request))
            self._refresh()

    def queue_clear(self):
        player = xbmc.Player()
        if player.isPlayingAudio():
            player.stop()
        xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        self._notify(tr(S.QUEUE_CLEARED))
        self._refresh()

    def queue_add(self):
        track = params_to_item(self.params)
        if not track or track["kind"] != "track":
            return self._notify(tr(S.INVALID_ID), xbmcgui.NOTIFICATION_ERROR)
        xbmc.PlayList(xbmc.PLAYLIST_MUSIC).add(build_url(action="play", **item_to_params(track)),
                                               self._track_item(track, playable=True))
        self._notify(tr(S.QUEUE_ADDED))

    # ---------------------------------------------------------- playback
    def _int(self, key, default=0):
        try:
            return int(self.params.get(key, default))
        except (TypeError, ValueError):
            return default

    def play_list(self):
        tracks = storage.get_context(self.params.get("ctx", ""))
        if not tracks:
            return self._notify(tr(S.NO_RESULTS), xbmcgui.NOTIFICATION_WARNING)
        index = min(max(self._int("index", 0), 0), len(tracks) - 1)
        if self.params.get("shuffle") == "1":
            random.shuffle(tracks)
            index = 0
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
        for track in tracks:
            playlist.add(build_url(action="play", **item_to_params(track)), self._track_item(track, playable=True))
        xbmc.Player().play(playlist, startpos=index)

    def play(self):
        """Resolve a single track right before Kodi starts it."""
        track = params_to_item(self.params)
        if not track or track["kind"] != "track":
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return self._notify(tr(S.INVALID_ID), xbmcgui.NOTIFICATION_ERROR)
        url, error = resolver.resolve(track["id"])
        if error:
            log.error("Could not resolve %s (%s): %s" % (track["id"], track["title"], error))
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return self._notify(tr(S.PLAY_ERROR, track["title"], error), xbmcgui.NOTIFICATION_ERROR, 6000)
        li = self._track_item(track)
        li.setPath(url)
        xbmcplugin.setResolvedUrl(self.handle, True, li)
        try:
            storage.add_history(track)
        except Exception:  # noqa: BLE001 - history must never break playback
            log.exception("Could not record history")

    # --------------------------------------------- favourites / playlists
    def fav_toggle(self):
        item = params_to_item(self.params)
        if item is None:
            return self._notify(tr(S.INVALID_ID), xbmcgui.NOTIFICATION_ERROR)
        added = storage.toggle_favorite(item)
        self._notify(tr(S.FAV_ADDED) if added else tr(S.FAV_REMOVED))
        self._refresh()

    def pl_new(self):
        name = xbmcgui.Dialog().input(tr(S.PL_NAME_PROMPT), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not name:
            return
        pl = storage.create_playlist(name)
        if pl:
            self._notify(tr(S.PL_CREATED, pl["name"]))
            self._refresh()

    def pl_rename(self):
        pl = storage.get_playlist(self.params.get("pl", ""))
        if pl is None:
            return
        name = xbmcgui.Dialog().input(tr(S.PL_NAME_PROMPT), defaultt=pl["name"],
                                      type=xbmcgui.INPUT_ALPHANUM).strip()
        if name and storage.rename_playlist(pl["id"], name):
            self._notify(tr(S.PL_RENAMED))
            self._refresh()

    def pl_delete(self):
        pl = storage.get_playlist(self.params.get("pl", ""))
        if pl is None:
            return
        if xbmcgui.Dialog().yesno(tr(S.ADDON_NAME), tr(S.PL_DELETE_CONFIRM, pl["name"])):
            storage.delete_playlist(pl["id"])
            self._notify(tr(S.PL_DELETED))
            self._refresh()

    def pl_add(self):
        track = params_to_item(self.params)
        if not track or track["kind"] != "track":
            return self._notify(tr(S.INVALID_ID), xbmcgui.NOTIFICATION_ERROR)
        lists = storage.get_playlists()
        choice = xbmcgui.Dialog().select(tr(S.PL_PICK), [tr(S.PL_NEW)] + [p["name"] for p in lists])
        if choice < 0:
            return
        if choice == 0:
            name = xbmcgui.Dialog().input(tr(S.PL_NAME_PROMPT), type=xbmcgui.INPUT_ALPHANUM).strip()
            target = storage.create_playlist(name) if name else None
        else:
            target = lists[choice - 1]
        if target and storage.add_track_to_playlist(target["id"], track):
            self._notify(tr(S.ADDED_TO, target["name"]))

    def pl_remove_track(self):
        if storage.remove_track_from_playlist(self.params.get("pl", ""), self._int("index", -1)):
            self._notify(tr(S.TRACK_REMOVED))
            self._refresh()

    def pl_open_id(self):
        text = xbmcgui.Dialog().input(tr(S.PL_ID_PROMPT), type=xbmcgui.INPUT_ALPHANUM)
        if not text.strip():
            return
        pid = extract_playlist_id(text)
        if not pid:
            return self._notify(tr(S.PL_ID_INVALID), xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Update(%s)" % build_url(action="playlist", id=pid))

    def history_clear(self):
        if xbmcgui.Dialog().yesno(tr(S.ADDON_NAME), tr(S.HISTORY_CLEAR_CONFIRM)):
            storage.clear_history()
            storage.clear_contexts()
            self._notify(tr(S.HISTORY_CLEARED))
            self._refresh()

    # ---------------------------------------------------- maintenance
    def clear_cache(self):
        self._notify(tr(S.CACHE_CLEARED, cache.clear()))

    def open_settings(self):
        xbmcaddon.Addon().openSettings()

    def diagnostics(self):
        addon = xbmcaddon.Addon()
        backend, version = ytm.backend_info()
        active = "ytmusicapi %s" % version if (version and settings.get_str("backend", "auto") != "builtin") \
            else "built-in client (innertube)"
        try:
            ms = ytm.get_client().ping()
            connection = "OK (%d ms)" % ms
        except Exception as exc:  # noqa: BLE001 - any failure is reported to the user
            connection = "FAILED: %s" % exc
        lines = [
            "MusicFlow %s" % addon.getAddonInfo("version"),
            "Kodi: %s | Python %s" % (xbmc.getInfoLabel("System.BuildVersion"), platform.python_version()),
            "",
            "YouTube Music connection: %s" % connection,
            "Catalogue backend: %s" % active,
            "Language/region: %s" % self._lang_key(),
            "",
            "Resolver setting: %s" % settings.get_str("resolver", "auto"),
            "plugin.video.youtube enabled: %s" % ("yes" if resolver.youtube_addon_enabled() else "NO"),
            "yt-dlp module available: %s" % ("yes" if resolver.ytdlp_available() else "no"),
            "",
            "Cache entries: %d (TTL %d min)" % (cache.count(), settings.get_int("cache_ttl", 30)),
            "Favourites: %d songs, %d albums, %d artists, %d playlists" % tuple(
                len(storage.get_favorites(k)) for k in KINDS),
            "Local playlists: %d | History: %d" % (len(storage.get_playlists()), len(storage.get_history())),
            "Data folder: %s" % settings.profile_dir(),
            "",
            "Log file: kodi.log (search for [MusicFlow])",
        ]
        xbmcgui.Dialog().textviewer(tr(S.DIAG_TITLE), "\n".join(lines))

    # ----------------------------------------------------------- dispatch
    def dispatch(self):
        action = self.params.get("action") or "main_menu"
        handler = getattr(self, action, None)
        if action.startswith("_") or not callable(handler) or action in ("dispatch", "client"):
            log.error("Unknown action: %r" % action)
            return self._fail(tr(S.INVALID_ID))
        listing = action not in _NO_LISTING
        try:
            handler()
        except ytm.YTMError as exc:
            log.error("Catalogue error in %s: %s" % (action, exc))
            message = tr(S.ERR_SERVICE, str(exc))
            if listing:
                self._fail(message)
            else:
                self._notify(message, xbmcgui.NOTIFICATION_ERROR, 6000)
        except Exception:  # noqa: BLE001 - last line of defence for the UI
            log.exception("Unhandled error in action %s" % action)
            if listing:
                self._fail(tr(S.UNKNOWN_ERROR))
            else:
                self._notify(tr(S.UNKNOWN_ERROR), xbmcgui.NOTIFICATION_ERROR, 6000)


def run(argv):
    handle = int(argv[1]) if len(argv) > 1 else -1
    params = parse_query(argv[2] if len(argv) > 2 else "")
    log.debug("Route: %s" % params)
    Plugin(handle, params).dispatch()
