# -*- coding: utf-8 -*-
"""Small on-disk JSON cache with a configurable time-to-live."""
import hashlib
import json
import os
import time

from . import log, settings


def _dir():
    path = os.path.join(settings.profile_dir(), "cache")
    os.makedirs(path, exist_ok=True)
    return path


def _file(key):
    return os.path.join(_dir(), hashlib.sha1(key.encode("utf-8")).hexdigest() + ".json")


def ttl_seconds():
    return max(0, settings.get_int("cache_ttl", 30)) * 60


def get(key):
    ttl = ttl_seconds()
    if ttl <= 0:
        return None
    path = _file(key)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            entry = json.load(handle)
        if time.time() - float(entry.get("ts", 0)) > ttl:
            return None
        return entry.get("data")
    except (OSError, ValueError, AttributeError):
        return None


def set(key, data):  # noqa: A001 - intentional name
    if ttl_seconds() <= 0:
        return
    path = _file(key)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump({"ts": time.time(), "data": data}, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except (OSError, TypeError, ValueError) as exc:
        log.warning("Cache write failed: %s" % exc)


def clear():
    removed = 0
    directory = _dir()
    for name in os.listdir(directory):
        try:
            os.remove(os.path.join(directory, name))
            removed += 1
        except OSError:
            pass
    return removed


def count():
    try:
        return len(os.listdir(_dir()))
    except OSError:
        return 0
