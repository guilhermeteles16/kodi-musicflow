# -*- coding: utf-8 -*-
"""MusicFlow - plugin entry point."""
import sys

from resources.lib import ui

if __name__ == "__main__":
    ui.run(sys.argv)
