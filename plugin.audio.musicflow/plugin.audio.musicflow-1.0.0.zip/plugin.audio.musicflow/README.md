# MusicFlow — YouTube Music para o Kodi

Add-on de música para o Kodi que pesquisa o catálogo público do YouTube Music
(músicas, artistas, álbuns e playlists) e reproduz as faixas no player nativo do Kodi.
Inclui playlists locais, favoritos, histórico e fila de reprodução.

> **Não afiliado ao Google/YouTube.** O add-on não hospeda conteúdo, não usa login,
> não contorna DRM, assinatura paga (Premium), restrição de idade/região nem qualquer
> mecanismo de proteção. O uso do serviço está sujeito aos termos do YouTube.

## Requisitos

| Item | Detalhe |
|---|---|
| Kodi | **20 (Nexus) e 21 (Omega)** são os alvos. Kodi 19 (Matrix) tem caminho de código de compatibilidade, mas não foi validado. |
| Python | O que acompanha o Kodi (3.8+). Nenhuma biblioteca externa é necessária. |
| Add-on **YouTube** (`plugin.video.youtube`) | **Obrigatório.** É declarado como dependência: o Kodi o instala sozinho a partir do repositório oficial, se estiver disponível. É ele que resolve o áudio das faixas. |
| `yt-dlp` (`script.module.yt-dlp`) | *Opcional.* Alternativa para obter o áudio (Configurações → Reprodução → Método de reprodução). |
| Internet | Necessária para pesquisar e reproduzir. |

## Instalação

1. Kodi → **Configurações** → **Sistema** → **Add-ons** → ative **Fontes desconhecidas**
   (necessário uma única vez para instalar ZIP de fora do repositório).
2. Kodi → **Add-ons** → **Instalar a partir de um arquivo ZIP** → selecione `plugin.audio.musicflow.zip`.
3. Aguarde a notificação “Add-on instalado”. Se o Kodi pedir para instalar dependências
   (YouTube), confirme.

Não é preciso copiar arquivos para pastas nem editar código.

## Como usar

Abra **Add-ons → Add-ons de música → MusicFlow**. Menu principal:

| Seção | O que faz |
|---|---|
| **Início** | Atalhos e as últimas faixas tocadas. |
| **Pesquisar** | Músicas, artistas e bandas, álbuns e playlists públicas. Guarda as pesquisas recentes. |
| **Populares e recomendações** | “Mais tocadas” da sua região e as prateleiras públicas do YouTube Music (não personalizadas). |
| **Artistas / Álbuns** | Pesquisa e a sua lista de favoritos. A página do artista traz músicas, álbuns, singles e artistas relacionados. |
| **Playlists** | Cria/renomeia/exclui playlists locais, abre playlists públicas pesquisando ou colando **link/ID**. |
| **Favoritos** | Músicas, álbuns, artistas e playlists. |
| **Histórico** | Últimas reproduções (pode ser desativado). |
| **Fila de reprodução** | Mostra a fila atual do Kodi; clique para pular para uma faixa, menu de contexto para remover, ou esvazie. |
| **Configurações** | Veja abaixo. |

### Pesquisar e reproduzir
1. **Pesquisar → Pesquisar músicas**, digite o termo e confirme.
2. Clique em uma música: toda a lista de resultados vira a fila e a reprodução começa nela;
   a faixa seguinte toca sozinha ao terminar. Use **Reproduzir tudo** ou **Reproduzir em ordem aleatória** no topo das listas.
3. Durante a reprodução, pausar, continuar, avançar/retroceder, parar e pular para a próxima/anterior
   usam os controles nativos do Kodi (controle remoto, teclado ou mouse). Título, artista e capa
   aparecem na tela de reprodução.
4. **Menu de contexto** (tecla `C`, botão de menu do controle, clique longo ou direito) em uma música:
   favoritar, adicionar a uma playlist local, adicionar à fila, ir ao artista, ir ao álbum.

### Configurações
- **Catálogo**: idioma dos títulos/metadados, região (afeta “mais tocadas” e a disponibilidade), resultados por pesquisa (5–50), biblioteca de catálogo, tempo limite de rede.
- **Biblioteca local**: ligar/desligar histórico, tamanho do histórico, validade do cache (0 desliga).
- **Reprodução**: método (Automático / add-on YouTube / yt-dlp) e “somente áudio”.
- **Dados e diagnóstico**: *Status da conexão e diagnóstico* (testa a conexão, mostra versões, backend, resolvedores, contagens), *Limpar histórico*, *Limpar cache*.

**Idioma da interface:** os textos do add-on seguem o idioma do Kodi (Configurações → Interface → Regional → Idioma).
Há tradução em **português do Brasil** e inglês (padrão). A opção “Idioma do catálogo” só afeta os dados vindos do YouTube Music.

## Autenticação

**Não é necessária e não está implementada.** Tudo funciona com dados públicos. Consequências:
- Não há acesso à sua biblioteca, curtidas, histórico ou recomendações personalizadas do YouTube Music.
- Playlists privadas/não listadas não abrem; conteúdos exclusivos para assinantes ou com restrição de idade podem falhar.
- Nenhuma senha, cookie de sessão ou token é pedido ou guardado. A única requisição fixa é um cookie de consentimento
  genérico (`SOCS=CAI`), não pessoal, que o site usa para dispensar o aviso de cookies.

## Onde ficam seus dados

Pasta de perfil do add-on (`userdata/addon_data/plugin.audio.musicflow/`): `favorites.json`, `playlists.json`,
`history.json`, `searches.json`, `contexts.json` (listas temporárias para a fila) e `cache/`.
Em caso de arquivo corrompido, o add-on o renomeia para `.bad` e recomeça vazio.

## Arquitetura (resumo)

- `resources/lib/ytm.py` — catálogo. Cliente interno (`urllib`, sem dependências) para o endpoint web público do
  YouTube Music, o mesmo tipo de acesso usado pela biblioteca `ytmusicapi`. Se `ytmusicapi` existir no Python do
  Kodi, é usada automaticamente com fallback para o cliente interno.
- `resources/lib/resolver.py` — resolução de áudio, **separada** do catálogo e feita só na hora de tocar
  (links nunca expiram na fila): add-on YouTube oficial, ou `yt-dlp` opcional.
- `resources/lib/ui.py` — rotas e telas com listas nativas do Kodi (independentes de skin).
- `resources/lib/storage.py`, `cache.py` — JSON no perfil, gravação atômica, validação de tudo que é lido.

## Limitações conhecidas

1. **Sem API oficial.** O YouTube Music não tem API pública oficial. O catálogo usa um endpoint web não documentado;
   o Google pode mudar o formato a qualquer momento e quebrar a pesquisa até uma atualização do add-on
   (ou da `ytmusicapi`). Falhas aparecem como mensagem clara e ficam no log.
2. **Reprodução depende do add-on YouTube.** Ele pode exigir configuração própria de chaves de API do Google,
   conforme a versão (veja a documentação dele). O parâmetro “somente áudio” depende da versão; se não for
   suportado, o vídeo será reproduzido (somente o áudio é útil aqui).
3. **Não validado em Kodi real nem contra o serviço ao vivo** (veja “Testes”). Pequenos ajustes de layout/rótulos podem ser necessários em alguma skin.
4. “Mais tocadas” e “recomendações” usam as prateleiras públicas; se o YouTube mudar a estrutura, a lista pode vir vazia.
5. Listas longas: pesquisa pagina até alguns lotes (melhor esforço); playlists/álbuns carregam até 500 faixas.
6. Faixas bloqueadas por região, só para assinantes ou removidas falham com aviso; o Kodi segue a regra normal de playlist.
7. Não há “tocar a seguir” (só “adicionar à fila”), letras, rádio/mix automático nem login.
8. A fila mostrada é a fila nativa do Kodi (música). Itens inseridos por outros add-ons também aparecem.

## Solução de problemas e logs

1. Ative o log de depuração: **Configurações → Sistema → Registro → Ativar registro de depuração**.
2. Reproduza o problema e abra o `kodi.log`:
   - Linux: `~/.kodi/temp/kodi.log` · LibreELEC/CoreELEC: `/storage/.kodi/temp/kodi.log`
   - Windows: `%APPDATA%\Kodi\kodi.log` · macOS: `~/Library/Logs/kodi.log`
   - Android: `Android/data/org.xbmc.kodi/files/.kodi/temp/kodi.log`
3. Procure por **`[MusicFlow]`** (erros do add-on) e pelo nome do add-on YouTube (erros de reprodução).
4. Use **Configurações → Dados e diagnóstico → Status da conexão e diagnóstico** para um resumo.
5. Pesquisa vazia/erro: confirme a internet, limpe o cache e tente trocar a região do catálogo.
6. “Add-on YouTube não instalado”: instale/ative `plugin.video.youtube` ou use o método `yt-dlp`.

## Desenvolvimento e testes

Os testes automatizados (`tests/`, fora do ZIP de instalação) usam stubs da API do Kodi:
`python3 -m unittest discover -s tests -p "test_musicflow.py"`.
